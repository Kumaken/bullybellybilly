import pygame
from pygame.locals import *
import tigad
from OpenGL.GL import *
from OpenGL.GLU import *
import copy
import math

verticies = [
	[1, -1, -1],
	[1, 1, -1],
	[-1, 1, -1],
	[-1, -1, -1],
	[1, -1, 1],
	[1, 1, 1],
	[-1, -1, 1],
	[-1, 1, 1]
	]

edges = [
	[0,1],
	[0,3],
	[0,4],
	[2,1],
	[2,3],
	[2,7],
	[6,3],
	[6,4],
	[6,7],
	[5,1],
	[5,4],
	[5,7]
	]
colors =[
	(1,0,0),
	(0,0,1),
	(0,0,1),
	(1,1,0),
	(0,1,1),
	(1,0,0),
	(0,1,0),
	(0,1,1),
	(1,0,0),
	(0,1,0),
	(0,1,1),
	(1,0,1),
	]

surfaces = [
	(4,0,3,6),
	(0,1,2,3),
	(3,2,7,6),
	(6,7,5,4),
	(4,5,1,0),
	(1,5,7,2)
	]

def sumbu3d():
	glBegin(GL_LINES)
	glColor3fv((0,0,1))
	glVertex3f(-200,0,0)
	glVertex3f(200,0,0)
	glVertex3f(0,-200,0)
	glVertex3f(0,200,0)
	glVertex3f(0,0,200)
	glVertex3f(0,0,-200)
	glEnd()


def Cube():
	glBegin(GL_LINES)
	for i in edges:
		for j in i:
			glColor3fv((0,0,0))
			glVertex3fv(verticies[j])
	glEnd()

	glBegin(GL_QUADS)
	x=0
	for surface in surfaces:
		x +=1
		for vertex in surface:
			glColor3fv(colors[x])
			glVertex3fv(verticies[vertex])
	glEnd()

def threeDinput(points):
	glBegin(GL_LINES)
	for tup in edges:
		for j in tup:
			glColor3fv((0,0,0))
			glVertex3f(points[j][0],points[j][1],points[j][2])
	glEnd()

	glBegin(GL_QUADS)
	x=0
	for surface in surfaces:
		x +=1
		for vertex in surface:
			glColor3fv(colors[x])
			glVertex3fv(points[vertex])
	glEnd()

def scale3(arr, arrf):
	for i in range(len(arr)) :
		for j in range(3):
			print(" cur val : ", round(arr[i][j],3))
			print(" tar val : ", round(arrf[i][j],3))
			if(round(arr[i][j],2)> round(arrf[i][j],2)):
				arr[i][j] = arr[i][j]- float(0.01)
			elif (round(arr[i][j],2) < round(arrf[i][j],2) ):
				arr[i][j] = arr[i][j]+ float(0.01)
			print("final cur val : ", round(arr[i][j],3))

def command3(arr, x):

	if (x[0] == "translate"):
		# translate <dx> <dy> <dz>
		arrf = copy.deepcopy(arr)
		arrf = tigad.translate3(arrf,x)
		#arr = tigad.translate3(arr, x)
		while( not (tigad.locsamelow3(arr,arrf))):
			if(round(tigad.sumOfX3(arr) ,2) > round(tigad.sumOfX3(arrf),2)):
				arr = tigad.translate3(arr, ['X',-0.1,0,0])
			if(round(tigad.sumOfX3(arr) ,2) < round(tigad.sumOfX3(arrf),2)):
				arr = tigad.translate3(arr, ['X',0.1,0,0])
			if(round(tigad.sumOfY3(arr),2) > round( tigad.sumOfY3(arrf),2)):
				arr = tigad.translate3(arr, ['X',0,-0.1,0])
			if(round(tigad.sumOfY3(arr),2) <round(tigad.sumOfY3(arrf),2)):
				arr = tigad.translate3(arr, ['X',0,0.1,0])
			if(round(tigad.sumOfZ3(arr),2) > round(tigad.sumOfZ3(arrf),2)):
				arr = tigad.translate3(arr, ['X',0,0,-0.1])
			if(round(tigad.sumOfZ3(arr),2) < round(tigad.sumOfZ3(arrf),2)):
				arr = tigad.translate3(arr, ['X',0,0,0.1])
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu3d()
			threeDinput(arr)
			pygame.display.flip()
			pygame.time.wait(10)

			print("CURRENT :")
			print(arr)
			print("TARGET :")
			print(arrf)

	elif (x[0] == "dilate"):
		# dilate <k>

		ktemp = 1.00
		while not(round(float(ktemp),2) == round(float(x[1]),2)):
			print("ktemp : ", round(float(ktemp),2))
			print("goal : ", round(float(x[1]),2))
			xtemp = ("X",ktemp)
			arrf = copy.deepcopy(arr)
			arrf = tigad.dilate3(arrf, xtemp)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu3d()
			threeDinput(arrf)
			pygame.display.flip()
			pygame.time.wait(10)

			if round(ktemp,2) < round(float(x[1]),2):
				ktemp += 0.01
			if round(ktemp,2) > round(float(x[1]),2):
				ktemp -= 0.01
		arr = copy.deepcopy(arrf)

	
	elif (x[0] == "rotate"):
		deg = 0
		while(not(round(float(deg),3) >= abs(round(float(x[2]),3)))):
			if float(x[1]) > 0.0:
				arr = tigad.rotate3(arr,['X',x[2],0.1])
			else:
				arr = tigad.rotate3(arr,['X',x[2],-0.1])
			deg = round(deg + 0.1, 13)
			print(deg)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu3d()
			threeDinput(arr)
			pygame.display.flip()
			pygame.time.wait(1)
		# rotate <param> <deg>
		# param = x, diputar terhadap sumbu x
		# param = y, diputar terhadap sumbu y
		# param = z, diputar terhadap sumbu z

	elif (x[0] == "reflect"):
		arrf = copy.deepcopy(arr)
		arrf = tigad.reflect3(arrf,x)

		while( not (tigad.locsamelow3(arr,arrf))):
			scale3(arr,arrf)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu3d()
			threeDinput(arr)
			pygame.display.flip()
			#pygame.time.wait(1)
		# reflect <param>
		# param = x, dicerminkan terhadap sumbu x
		# param = y, dicerminkan terhadap sumbu y
		# param = z, dicerminkan terhadap sumbu z
		arr = tigad.reflect3(arr, x)

	elif (x[0] == "shear"):
		arrtemp = copy.deepcopy(arr)
		arrf = tigad.shear3(arrtemp,x)

		while( not (tigad.locsamelow3(arr,arrf))):
			scale3(arr,arrf)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu3d()
			threeDinput(arr)
			pygame.display.flip()
			#pygame.time.wait(1)
			print("CURRENT :")
			print(arr)
			print("TARGET :")
			print(arrf)
		# shear <param> <k>
		# param = x, shear terhadap sumbu x
		# param = y, shear terhadap sumbu y
		# param = z, shear terhadap sumbu z
		arr = tigad.shear3(arr, x)
	
	elif (x[0] == "stretch"):
		arrtemp = copy.deepcopy(arr)
		arrf = tigad.stretch3(arrtemp,x)

		while( not (tigad.locsamelow3(arr,arrf))):
			scale3(arr,arrf)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu3d()
			threeDinput(arr)
			pygame.display.flip()
			#pygame.time.wait(1)
			print("CURRENT :")
			print(arr)
			print("TARGET :")
			print(arrf)
		# stretch <param> <k>
		# param = x, stretch terhadap sumbu x
		# param = y, stretch terhadap sumbu y
		# param = z, stretch terhadap sumbu z
	
	elif (x[0] == "custom"):
		# custom <a> <b> <c> <d> <e> <f> <g> <h> <i>
		arr = tigad.custom3(arr, x)
	
	else: #input tidak valid
		print("input tidak valid")

	return arr

posisiawal = []
def main3d():
	#JGN LUPA APUS
	arr = copy.deepcopy(verticies)
	posisiawal = copy.deepcopy(verticies)
	
	pygame.init()
	display = (800,600)
	pygame.display.set_mode(display, DOUBLEBUF|OPENGL)

	gluPerspective(45, (display[0]/display[1]), 0.1, 50.0)

	glTranslatef(0.0,0.0, -10)

	gluLookAt(3.0, 4.0, 5.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0)
	
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			pygame.quit()
			quit()
	
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
	sumbu3d()
	Cube()
	pygame.display.flip()
	pygame.time.wait(10)
	
	# kebawah masih copas 2D	
	aksi = input()
	aksi = aksi.split()

	while (aksi[0]!="exit"):
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					pygame.quit()
					quit()

			if (aksi[0] == "multiple"):
				
				n = int(input())

				while (n>0):
					aksi = input()
					aksi = aksi.split()
					arr = command3(arr, aksi)
					n = n - 1

			elif (aksi[0] == "reset"):
				arr = copy.deepcopy(posisiawal)
				#print(arr)
				#print(posisiawal)
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
				sumbu3d()
				threeDinput(arr)
				pygame.display.flip()
				pygame.time.wait(10)

			else:
				arr = command3(arr, aksi)

			aksi = input()
			aksi = aksi.split()

			pygame.display.flip()
			pygame.time.wait(10)

main3d()

