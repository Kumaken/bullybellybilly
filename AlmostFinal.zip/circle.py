import pygame
from pygame.locals import *
import math
from OpenGL.GL import *
from OpenGL.GLU import *
import hello
import copy
from decimal import Decimal, ROUND_HALF_EVEN

#GLOBAL VARS :
radius = 0

verticies = (
	(1, -1, -1),
	(1, 1, -1),
	(-1, 1, -1),
	(-1, -1, -1),
	(1, -1, 1),
	(1, 1, 1),
	(-1, -1, 1),
	(-1, 1, 1)
	)

edges = (
	(0,1),
	(0,3),
	(0,4),
	(2,1),
	(2,3),
	(2,7),
	(6,3),
	(6,4),
	(6,7),
	(5,1),
	(5,4),
	(5,7)
	)

posisiawal = []

def sumbu2d():
	glBegin(GL_LINES)
	glVertex2f(-99,0)
	glVertex2f(99,0)
	glVertex2f(0,-99)
	glVertex2f(0,99)
	glEnd()

def twoD():
	glBegin(GL_LINE_LOOP)
	for x in range(len(posisiawal)):
		#print(x)
		#print(posisiawal[0][0])
		#print(posisiawal[int(x)][0])
		glVertex2f((posisiawal[int(x)][0]), (posisiawal[int(x)][1]))
	glEnd()

def twoDinput(points):
	glBegin(GL_LINE_LOOP)
	for x in points:
		glVertex2f(x[0],x[1])
	glEnd()

def drawFilledCircle(x, y, radius):
	triangleAmount = 200
	twicePi = 2.0 * math.pi;
	
	radius = float(radius)
	x = float(x)
	y = float(y)
	glBegin(GL_TRIANGLE_FAN)
	glVertex2f(x, y) 
	for i in range(triangleAmount+1): 
		glVertex2f(x + (radius * math.cos(i *  twicePi / triangleAmount)), y + (radius * math.sin(i * twicePi / triangleAmount)))
	glEnd()

def drawHollowCircle(x, y, radius):
	lineAmount = 200
	twicePi = 2.0 * math.pi;
	
	glBegin(GL_LINE_STRIP) 
	glVertex2f(x, y)  
	for i in range(lineAmount+1):
		glVertex2f(x + (radius * math.cos(i *  twicePi / lineAmount)), y + (RADIUS* math.sin(i * twicePi / lineAmount))) 
		glEnd()

def scale(arr, arrf):
	for i in range(len(arr)) :
		for j in range(2):
			print(" cur val : ", round(arr[i][j],3))
			print(" tar val : ", round(arrf[i][j],3))
			if(round(arr[i][j],2)> round(arrf[i][j],2)):
				arr[i][j] = arr[i][j]- float(0.01)
			elif (round(arr[i][j],2) < round(arrf[i][j],2) ):
				arr[i][j] = arr[i][j]+ float(0.01)
			print("final cur val : ", round(arr[i][j],3))

def command(arr, x, isCircle):
	global radius

	if (x[0] == "translate"):
		if not(isCircle):
			arrtemp = copy.deepcopy(arr)
			arrf = hello.finalarr(arrtemp,x)
			while( not (hello.locsame(arr,arrf))):
				if(hello.sumOfX(arr) > hello.sumOfX(arrf)):
					arr = hello.translate(arr, ['X',-0.1,0])
				if(hello.sumOfX(arr) < hello.sumOfX(arrf)):
					arr = hello.translate(arr, ['X',0.1,0])
				if(hello.sumOfY(arr) > hello.sumOfY(arrf)):
					arr = hello.translate(arr, ['X',0,-0.1])
				if(hello.sumOfY(arr) <hello.sumOfY(arrf)):
					arr = hello.translate(arr, ['X',0,0.1])
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
				sumbu2d()
				twoDinput(arr)
				pygame.display.flip()
				pygame.time.wait(10)
				print(arr)
			print('END')
		else:
			arrtemp = copy.deepcopy(arr)
			arrf = hello.Ctranslate(arrtemp,x)
			print (arr)
			print (arrf)
			while( not ((round(arr[0][0],2) == round(arrf[0][0],2)) and (round(arr[0][1],2) == round(arrf[0][1]),2))):
				if(round(arr[0][0],2) < round(arrf[0][0],2)):
					arr[0][0] += 0.1 
				if(round(arr[0][0],2) > round(arrf[0][0],2)):
					arr[0][0] -= 0.1 
				if(round(arr[0][1],2) < round(arrf[0][1],2)):
					arr[0][1] += 0.1 
				if(round(arr[0][1],2) > round(arrf[0][1],2)):
					arr[0][1] -= 0.1 

				"""print("X : " ,round(arr[0][0],2))
				print("Y : " ,round(arr[0][1],2))
				print("target X : " ,round(arrf[0][0],2))
				print("target Y : " ,round(arrf[0][1],2))"""
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
				sumbu2d()
				drawFilledCircle(arr[0][0], arr[0][1], radius)
				pygame.display.flip()
				pygame.time.wait(10)


	elif (x[0] == "dilate"):
		"""arrtemp = copy.deepcopy(arr)
		arrf = hello.dilate(arrtemp,x)

		while( not (hello.locsamelow(arr,arrf))):
			scale(arr,arrf)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu2d()
			twoDinput(arr)
			pygame.display.flip()
			#pygame.time.wait(1)
			print("CURRENT :")
			print(arr)
			print("TARGET :")
			print(arrf)"""
		if not(isCircle):
			ktemp = 1.00
			while not(round(float(ktemp),2) == round(float(x[1]),2)):
				print("ktemp : ", round(float(ktemp),2))
				print("goal : ", round(float(x[1]),2))
				xtemp = ("X",ktemp)
				arrtemp = copy.deepcopy(arr)
				arrtemp = hello.dilate(arrtemp, xtemp)
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
				sumbu2d()
				twoDinput(arrtemp)
				pygame.display.flip()
				pygame.time.wait(10)

				if round(ktemp,2) < round(float(x[1]),2):
					ktemp += 0.01
				if round(ktemp,2) > round(float(x[1]),2):
					ktemp -= 0.01
			arr = copy.deepcopy(arrtemp)
		else :
			finalRad = hello.Cdilate(arr,x,radius)
			print(round(finalRad,2))
			while not(round(float(radius),2) == round(float(finalRad),2)) :
				if round(radius,2) < round(finalRad,2) :
					radius += 0.01
				if round(radius,2) > round(finalRad,2) :
					radius -= 0.01
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
				sumbu2d()
				drawFilledCircle(arr[0][0], arr[0][1], radius)
				pygame.display.flip()
				pygame.time.wait(10)
				print(round(radius,2))
	
	elif (x[0] == "rotate"):
		deg = 0
		while(not(round(float(deg),3) >= abs(round(float(x[1]),3)))):
			if float(x[1]) > 0.0:
				arr = hello.rotate(arr,['X',0.1,x[2],x[3]])
			else:
				arr = hello.rotate(arr,['X',-0.1,x[2],x[3]])
			deg = round(deg + 0.1, 13)
			print(deg)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu2d()
			if not(isCircle):
				twoDinput(arr)
			else:
				drawFilledCircle(arr[0][0], arr[0][1], radius)
			pygame.display.flip()
			pygame.time.wait(1)


	elif (x[0] == "reflect"):
		arrf = copy.deepcopy(arr)
		arrf = hello.reflect(arrf,x)

		while( not (hello.locsamelow(arr,arrf))):
			scale(arr,arrf)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu2d()
			
			if not(isCircle):
				twoDinput(arr)
			else:
				drawFilledCircle(arr[0][0], arr[0][1], radius)

			pygame.display.flip()
			#pygame.time.wait(1)

	elif (x[0] == "shear"):
		arrtemp = copy.deepcopy(arr)
		arrf = hello.shear(arrtemp,x)

		while( not (hello.locsamelow(arr,arrf))):
			scale(arr,arrf)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu2d()
			if not(isCircle):
				twoDinput(arr)
			else:
				drawFilledCircle(arr[0][0], arr[0][1], radius)
			pygame.display.flip()
			#pygame.time.wait(1)
			print("CURRENT :")
			print(arr)
			print("TARGET :")
			print(arrf)

	elif (x[0] == "stretch"):
		arrtemp = copy.deepcopy(arr)
		arrf = hello.stretch(arrtemp,x)

		while( not (hello.locsamelow(arr,arrf))):
			scale(arr,arrf)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu2d()
			if not(isCircle):
				twoDinput(arr)
			else:
				drawFilledCircle(arr[0][0], arr[0][1], radius)
			pygame.display.flip()
			#pygame.time.wait(1)
			print("CURRENT :")
			print(arr)
			print("TARGET :")
			print(arrf)
	
	elif (x[0] == "custom"):
		arrtemp = copy.deepcopy(arr)
		arrf = hello.custom(arrtemp,x)

		while( not (hello.locsamelow(arr,arrf))):
			scale(arr,arrf)
			glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
			sumbu2d()
			if not(isCircle):
				twoDinput(arr)
			else:
				drawFilledCircle(arr[0][0], arr[0][1], radius)
			pygame.display.flip()
			#pygame.time.wait(1)
			print("CURRENT :")
			print(arr)
			print("TARGET :")
			print(arrf)
			

	else: #input tidak valid
		print("input tidak valid")

	return arr

def main2d():
	global radius
	#Bully!
	isCircle = False
	n = int(input("Input N  : "))

	for i in range(n):
		z = list(map(float,input().split(',')))
		posisiawal.insert(0, z)

	arr = copy.deepcopy(posisiawal)

	if (n == 1) :
		print("YOU ARE INPUTTING FOR A CIRCLE!")
		radius = float(input("INPUT RADIUS : "))
		isCircle = True
	#print(posisiawal)

	# Initialize Window for OpenGL
	pygame.init()
	display = (800,600)
	pygame.display.set_mode(display, DOUBLEBUF|OPENGL)

	gluPerspective(45, (display[0]/display[1]), 0.1, 50.0)

	glTranslatef(0.0,0.0, -15)
	for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				quit()
	glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)

	# MAKE OBJECT

	if (n == 1) :
		drawFilledCircle((arr[0][0]), (arr[0][1]),radius)
	else :
		twoD()

	# MAKE AXIS 2 Dimension
	sumbu2d()

	# Visualized OBJECT and AXIS
	pygame.display.flip()

	aksi = input()
	aksi = aksi.split()

	while (aksi[0]!="exit"):
		for event in pygame.event.get():
			if event.type == pygame.QUIT:
				pygame.quit()
				quit()

		if (aksi[0] == "multiple"):
			
			n = int(input())

			while (n>0):
				aksi = input()
				aksi = aksi.split()
				arr = command(arr, aksi, isCircle)
				n = n - 1

		elif (aksi[0] == "reset"):
			if(not(isCircle)):
				arr = copy.deepcopy(posisiawal)
				#print(arr)
				#print(posisiawal)
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
				sumbu2d()
				twoDinput(arr)
				pygame.display.flip()
				pygame.time.wait(10)
			else:
				glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT)
				sumbu2d()
				drawFilledCircle(posisiawal[0][0],posisiawal[0][1],radius)
				pygame.display.flip()
				pygame.time.wait(10)
		else:
			arr = command(arr, aksi, isCircle)

		aksi = input()
		aksi = aksi.split()

		pygame.display.flip()
		pygame.time.wait(10)


main2d()